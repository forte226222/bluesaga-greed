﻿BLUE SAGA

=========



A free indie mmorpg by Jonathan Stahl for PC and Mac.


Set in a fantasy world with pirate theme, choose your looks and class, 
get a boat, then get out into the world, explore, do quests, 
discover hidden treasures and defeat mighty monsters. 
 


Follow the development of the game on 
twitter.com/bluesagagame 

or visit the site and forums at 
www.bluesaga.org



Thanks to LWJGL for making java game development easy and 
thanks to Kevin Glass for making it even easier with his Slick-library.



Big thanks to Waynejetski for helping me whenever I get stuck on code 
related problems.



INSTRUCTIONS

============



1. Double-click on the BlueSaga icon to start the launcher

2. Choose a server to connect to

2. Let it check for updates, it will download them automatically if available.

3. The game will start automatically after the updates are done. 

4. You need an account to play, don’t worry, it is free, 
so just go to www.bluesaga.org and create one.
5. Have fun!